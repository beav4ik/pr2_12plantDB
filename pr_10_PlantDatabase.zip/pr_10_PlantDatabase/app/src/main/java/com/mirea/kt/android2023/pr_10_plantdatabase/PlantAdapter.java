package com.mirea.kt.android2023.pr_10_plantdatabase;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PlantAdapter extends RecyclerView.Adapter<PlantAdapter.PlantViewHolder> {

    private List<Plant> plants;

    public PlantAdapter(List<Plant> plants) {
        this.plants = plants;
    }

    @Override
    public PlantViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.plant_item, parent, false);
        return new PlantViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PlantViewHolder holder, int position) {
        Plant plant = plants.get(position);

        holder.nameTextView.setText(plant.getName());
        holder.varietyTextView.setText(plant.getVariety());
        holder.isGreenhouseTextView.setText(plant.isGreenhouse() ? "Да" : "Нет");
    }

    @Override
    public int getItemCount() {
        return plants.size();
    }

    public class PlantViewHolder extends RecyclerView.ViewHolder {

        TextView nameTextView, varietyTextView, isGreenhouseTextView;

        public PlantViewHolder(View itemView) {
            super(itemView);

            nameTextView = itemView.findViewById(R.id.name_text_view);
            varietyTextView = itemView.findViewById(R.id.variety_text_view);
            isGreenhouseTextView = itemView.findViewById(R.id.is_greenhouse_text_view);
        }
    }

}