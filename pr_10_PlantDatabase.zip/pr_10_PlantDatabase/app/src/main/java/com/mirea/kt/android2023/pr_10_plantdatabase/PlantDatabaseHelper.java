package com.mirea.kt.android2023.pr_10_plantdatabase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class PlantDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "plant_database";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_NAME = "plants";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_VARIETY = "variety";
    private static final String COLUMN_IS_GREENHOUSE = "is_greenhouse";

    private static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + "(" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_NAME + " TEXT, " +
                    COLUMN_VARIETY + " TEXT, " +
                    COLUMN_IS_GREENHOUSE + " INTEGER" +
                    ")";

    public PlantDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void addPlant(Plant plant) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, plant.getName());
        values.put(COLUMN_VARIETY, plant.getVariety());
        values.put(COLUMN_IS_GREENHOUSE, plant.isGreenhouse() ? 1 : 0);

        db.insert(TABLE_NAME, null, values);

        db.close();
    }

    public List<Plant> getAllPlants() {
        List<Plant> plants = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(TABLE_NAME, new String[] {COLUMN_ID, COLUMN_NAME, COLUMN_VARIETY, COLUMN_IS_GREENHOUSE},
                null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex(COLUMN_ID));
                String name = cursor.getString(cursor.getColumnIndex(COLUMN_NAME));
                String variety = cursor.getString(cursor.getColumnIndex(COLUMN_VARIETY));
                boolean isGreenhouse = cursor.getInt(cursor.getColumnIndex(COLUMN_IS_GREENHOUSE)) == 1;

                Plant plant = new Plant(id, name, variety, isGreenhouse);
                plants.add(plant);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return plants;
    }
}