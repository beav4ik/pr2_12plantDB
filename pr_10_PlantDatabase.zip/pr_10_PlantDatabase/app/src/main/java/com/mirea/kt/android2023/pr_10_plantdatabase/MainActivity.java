package com.mirea.kt.android2023.pr_10_plantdatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText nameEditText, varietyEditText;
    private Switch greenhouseSwitch;
    private Button addPlantButton, plantListButton;

    private PlantDatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new PlantDatabaseHelper(this);

        nameEditText = findViewById(R.id.name_edit_text);
        varietyEditText = findViewById(R.id.variety_edit_text);
        greenhouseSwitch = findViewById(R.id.greenhouse_switch);
        addPlantButton = findViewById(R.id.add_plant_button);

        addPlantButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString();
                String variety = varietyEditText.getText().toString();
                boolean isGreenhouse = greenhouseSwitch.isChecked();

                Plant plant = new Plant(name, variety, isGreenhouse);

                databaseHelper.addPlant(plant);

                nameEditText.setText("");
                varietyEditText.setText("");
                greenhouseSwitch.setChecked(false);

                Toast.makeText(MainActivity.this, "Растение добавлено!", Toast.LENGTH_SHORT).show();
            }
        });

        TextView variantTextView = findViewById(R.id.variant_text_view);
        variantTextView.setText("Бобровский С.И., Вариант-4");

        plantListButton = findViewById(R.id.plant_list_button);
        plantListButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PlantListActivity.class);
                startActivity(intent);
            }
        });
    }
}