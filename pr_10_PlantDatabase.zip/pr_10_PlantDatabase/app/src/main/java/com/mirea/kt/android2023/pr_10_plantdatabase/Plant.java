package com.mirea.kt.android2023.pr_10_plantdatabase;

public class Plant {

    private int id;
    private String name;
    private String variety;
    private boolean isGreenhouse;

    public Plant(int id, String name, String variety, boolean isGreenhouse) {
        this.id = id;
        this.name = name;
        this.variety = variety;
        this.isGreenhouse = isGreenhouse;
    }

    public Plant(String name, String variety, boolean isGreenhouse) {
        this.name = name;
        this.variety = variety;
        this.isGreenhouse = isGreenhouse;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getVariety() {
        return variety;
    }

    public boolean isGreenhouse() {
        return isGreenhouse;
    }
}